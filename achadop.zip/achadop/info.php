﻿<?php
// Abrindo uma imagem PNG
  $img = imagecreatefrompng('imagens/estrela.png');
  // Obtendo o tamanho do arquivo de imagem
?>