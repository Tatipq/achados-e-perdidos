﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Achados e perdidos UDF</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/add.css">	
</head>

<body>

<!-- Imagem e texto do menu -->
<nav class="navbar navbar-light bg-primary rounded-bottom">
  <a href="index.php?page=home.php"><img src="imagens/estrela.png" width="90" height="90"></a>
  	<a href="index.php?page=home.php" style="text-decoration:none;"><h1 style="color:#FFFFFF;">Achados e Perdidos UDF</h1></a>
  <a class="navbar-brand" href="index.php?page=home"><img src="imagens/casa.png" height="80" width="80"></a>
</nav>
<!--Alternação entre as paginas -->
<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<?php
					
						include("config.php");
						
						switch(@$_REQUEST["page"]){
							case "achados":
								include("achados.php");
							break;
							case "perdidos":
								include("perdidos.php");
							break;
							case "info":
								include("cadastro.php");
							break;
							case "blog":
								include("blog.php");
							break;
							case "nao-encontrado":
								include("cadastronencontrado.php");
							case "pesquisa":
								include("pesquisa.php");
							break;
							case "pesquisa-blog":
								include("pesquisa-blog.php");
							break;
							default:
								include("home.php");
						}
					?>
				</div>
			</div>
		</div>
        <ul class="pesquisa">
        
        </ul>

<script src="js/jquery-3.2.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<!--Necessario para iniciar o modal-->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- Fim do codigo para modal-->
</body>
</html>