﻿<!--Quadro de opções-->
<div class="card" style="margin-top:10%; margin-left:20%; margin-right:20%; height:300px;">
  <div class="card-body">
  	<h2 align="center">Escolha uma opção</h2>
    
<!-- Botões de achados e perdido-->
 <div style="margin-top:6%;">
    <a href="index.php?page=achados" style="text-decoration:none;"><button type="button" class="btn btn-primary btn-lg btn-block">Achei</button></a>
    </div>
 <div style="margin-top:3%;">
	<a href="index.php?page=perdidos" style="text-decoration:none;"><button type="button" class="btn btn-secondary btn-lg btn-block">Perdi</button></a>
    </div>
  </div><!-- fim dos botões-->
</div><!--fim de quadro de opções-->

			